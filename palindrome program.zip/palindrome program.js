function checkWord(string) {

    const len = string.length;

    for(let i = 0; i < len / 2; i++) {

        if (string[i] !== string[len - 1 -i]) {
            alert("Bukan Palindrome");
        }
    }
    alert("Merupakan Palindrome");
}

const string = prompt('Masukkan Kata : ');

const value = checkWord(string);

console.log(value);